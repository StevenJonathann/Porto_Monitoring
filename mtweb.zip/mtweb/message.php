<?php
    if(isset($_SESSION['message'])) :
?>

    <div class="alert alert-warning alert-dismissible align-items-center fade show custom-message" role="alert" style="font-size: 12px; padding: 4px; margin-top: 13px; width: 70%;">
        <?= $_SESSION['message']; ?>
        
    </div>

<?php 
    unset($_SESSION['message']);
    endif;
?>