<?php
session_start();
require 'dbcon2.php';

// nilai
if(isset($_POST['delete_nilai']))
{
    $students_id = mysqli_real_escape_string($con, $_POST['delete_nilai']);

    $query = "DELETE FROM student WHERE id='$students_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Data Deleted Successfully";
        header("Location: nilai.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Data Not Deleted";
        header("Location: nilai.php");
        exit(0);
    }
}

if(isset($_POST['update_nilai']))
{
    $students_id = mysqli_real_escape_string($con, $_POST['students_id']);

    $name = mysqli_real_escape_string($con, $_POST['name']);
    $quiz1_1 = mysqli_real_escape_string($con, $_POST['quiz1_1']);
    $quiz2_1 = mysqli_real_escape_string($con, $_POST['quiz2_1']);
    $quiz3_1 = mysqli_real_escape_string($con, $_POST['quiz3_1']);
    $uts_1 = mysqli_real_escape_string($con, $_POST['uts_1']);
    $uas_1 = mysqli_real_escape_string($con, $_POST['uas_1']);
    $quiz1_2 = mysqli_real_escape_string($con, $_POST['quiz1_2']);
    $quiz2_2 = mysqli_real_escape_string($con, $_POST['quiz2_2']);
    $quiz3_2 = mysqli_real_escape_string($con, $_POST['quiz3_2']);
    $uts_2 = mysqli_real_escape_string($con, $_POST['uts_2']);
    $uas_2 = mysqli_real_escape_string($con, $_POST['uas_2']);

    $query = "UPDATE student SET name='$name', quiz1_1='$quiz1_1', quiz2_1='$quiz2_1', quiz3_1='$quiz3_1', 
    uts_1='$uts_1', uas_1='$uas_1', quiz1_2='$quiz1_2', quiz2_2='$quiz2_2', quiz3_2='$quiz3_2', uts_2='$uts_2', uas_2='$uas_2' WHERE id='$students_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Nilai Updated Successfully";
        header("Location: nilai.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Nilai Not Updated";
        header("Location: nilai.php");
        exit(0);
    }

}


    if(isset($_POST['simpan_nilai']))
    {
        $name = mysqli_real_escape_string($con, $_POST['name']);
        $quiz1_1 = mysqli_real_escape_string($con, $_POST['quiz1_1']);
        $quiz2_1 = mysqli_real_escape_string($con, $_POST['quiz2_1']);
        $quiz3_1 = mysqli_real_escape_string($con, $_POST['quiz3_1']);
        $uts_1 = mysqli_real_escape_string($con, $_POST['uts_1']);
        $uas_1 = mysqli_real_escape_string($con, $_POST['uas_1']);
        $quiz1_2 = mysqli_real_escape_string($con, $_POST['quiz1_2']);
        $quiz2_2 = mysqli_real_escape_string($con, $_POST['quiz2_2']);
        $quiz3_2 = mysqli_real_escape_string($con, $_POST['quiz3_2']);
        $uts_2 = mysqli_real_escape_string($con, $_POST['uts_2']);
        $uas_2 = mysqli_real_escape_string($con, $_POST['uas_2']);
        
        $query = "INSERT INTO student (name,quiz1_1,quiz2_1,quiz3_1,uts_1,uas_1,quiz1_2,quiz2_2,quiz3_2,uts_2,uas_2) 
        VALUES ('$name','$quiz1_1','$quiz2_1','$quiz3_1','$uts_1','$uas_1','$quiz1_2','$quiz2_2','$quiz3_2','$uts_2','$uas_2')";

        $query_run = mysqli_query($con, $query);
        if($query_run)
        {
            $_SESSION['message'] = "Data Created Successfully";
            header("Location: nilai-create.php");
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "Data Not Created";
            header("Location: nilai-create.php");
            exit(0);
        }
    }
?>