<?php
    session_start();
    require 'dbcon.php';
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	  <title>Student Performance System</title>
	    <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
	    <!----css3---->
        <link rel="stylesheet" href="css/custom.css">
		
		
		
		<!--google fonts -->
	    <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
	
	
	   <!--google material icon-->
      <link href="https://fonts.googleapis.com/css2?family=Material+Icons"rel="stylesheet">

  </head>
  <body>
 
<div class="wrapper">
     
	  <div class="body-overlay"></div>
	 
	 <!-------sidebar--design------------>
	 
	 <div id="sidebar">
	    <div class="sidebar-header pl-4 ml-2 pb-2">
		   <a href="index.php"><h3><img src="img/logo.png" class="img-fluid imgsize ml-4"/>Student Performance System</a></h3>
		</div>
		<ul class="list-unstyled component m-0">
		  <li class="active">
		  <a href="index.php" class="dashboard"><i class="material-icons">dashboard</i>Dashboard </a>
		  </li>
		  <li class="dropdown">
		  <a href="infoguru.php" 
		  class="">
		  <i class="material-icons">info</i>Tentang Guru
		  </a>
		  </li>
		  <li class="dropdown">
		  <a href="chart.php">
		  <i class="material-icons">insert_chart</i>Chart
		  </a>
		  </li>
		  <li class="dropdown">
		  <a href="#homeSubmenu3" data-toggle="collapse" aria-expanded="false" 
		  class="dropdown-toggle">
		  <i class="material-icons">list</i>Laporan
		  </a>
		  <ul class="collapse list-unstyled menu" id="homeSubmenu3">
		  	 <li><a href="log.php">Data Monitoring</a></li>
		     <li><a href="nilai.php">Data Nilai Siswa</a></li>
		  </ul>
		  </li> 
		</ul>
	 </div>
	 
   <!-------sidebar--design- close----------->
   
   
   
      <!-------page-content start----------->
   
      <div id="content">
	     
		  <!------top-navbar-start-----------> 
		     
		  <div class="top-navbar">
		     <div class="xd-topbar">
			     <div class="row">
				     <div class="col-2 col-md-1 col-lg-1 order-2 order-md-1 align-self-center">
					    <div class="xp-menubar">
						    <span class="material-icons text-white">signal_cellular_alt</span>
						</div>
					 </div>
					 
					 <div class="col-md-5 col-lg-3 order-3 order-md-2">
					     <div class="xp-searchbar">
						     <form>
							 </form>
						 </div>
					 </div>
					 
					 
					 <div class="col-10 col-md-6 col-lg-8 order-1 order-md-3">
					     <div class="xp-profilebar text-right">
						    <nav class="navbar p-0">
							   <ul class="nav navbar-nav flex-row ml-auto">
							   <li class="dropdown nav-item active">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <span class="material-icons">notifications</span>
								  <span class="notification">3</span>
								 </a>
								  <ul class="dropdown-menu">
								  <li><a href="#"> Data Baru Telah Ditambahkan</a></li>
									 <li><a href="#"> Data Berhasil Diupdate</a></li>
									 <li><a href="#"> Data Berhasil Dihapus</a></li>
								  </ul>
							   </li>
							   <li class="dropdown nav-item">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <img src="img/profile.png" style="width:30px; border-radius:50%;"/>
								  <span class="xp-user-live"></span>
								 </a>
								  <ul class="dropdown-menu small-menu">
								     <li><a href="infoguru.php">
									 <span class="material-icons">person_outline</span>
									 Profile
									 </a></li>
									 <li><a href="setting.php">
									 <span class="material-icons">settings</span>
									 Manage User
									 </a></li>
									 <li><a href="login.php">
									 <span class="material-icons">logout</span>
									 Logout
									 </a></li>
									 <li><a href="register.php">
									 <span class="material-icons">how_to_reg</span>
									 Register
									 </a></li>
									 
								  </ul>
							   </li>
							   
							   
							   </ul>
							</nav>
						 </div>
					 </div>
					 
				 </div>
				 
				 <div class="xp-breadcrumbbar text-center">
				    <h4 class="page-title">Dashboard</h4>
					<ol class="breadcrumb">
					  <li class="breadcrumb-item">SPS</li> <!--sebelum text bs input link-->
					  <li class="breadcrumb-item active" aria-curent="page">Dashboard</li>
					</ol>
				 </div>
				 
				 
			 </div>
		  </div>
		  <!------top-navbar-end-----------> 
		  
		  <div class="card-group pt-4">
			<div class="card">
		
			  <div class="card-body" style="background-color:rgb(121, 26, 26); color: #fff;">
				<h5 class="card-title">Guru</h5>
				<p class="card-text">1</p>
				<p class="card-text"><small class="text-mutedd">Last updated 4 months ago</small></p>
			  </div>
			</div>
			<div class="card">
		
			  <div class="card-body" style="background-color:rgb(21, 55, 117); color: #fff;">
				<h5 class="card-title">Siswa</h5>
				<p class="card-text">3</p>
				<p class="card-text"><small class="text-mutedd">Last updated 4 months ago</small></p>
			  </div>
			</div>
			<div class="card">
			 
			  <div class="card-body" style="background-color:rgb(25, 77, 47); color: #fff;">
				<h5 class="card-title">Mata Pelajaran</h5>
				<p class="card-text">1</p>
				<p class="card-text"><small class="text-mutedd">Last updated 4 months ago</small></p>
			  </div>
			</div>
		  </div>
		  
		   <!------main-content-start-----------> 
		   
		      <div class="container mt-4">

			 
			 
        <div class="row">
		
            <div class="col-md-12">
                <div class="card table-wrapper">
                    <div class="card-header table-title tableheight" style="height:70%;">
						<div class="row">
                            <div class="col-md-4 pt-3">
                            <h4>Student Details</h4> 
                            </div>
                            <div class="col-md-6 pr-5">
                            <?php include('message.php'); ?>
                            </div>
                            <div class="col-md-2 pt-3">
                            <a href="student-create.php" class="btn btn-primary float"> Add Student </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
					
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Student Name</th>
                                    <th>Email</th>
                                    <th>Student Phone</th>
                                    <th>Parent Phone</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
				

                                <?php 
                                    $query = "SELECT * FROM students";
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $student)
                                        {
                                            ?>
                                            <tr>
                                                <td><?= $student['id']; ?></td>
                                                <td><?= $student['name']; ?></td>
                                                <td><?= $student['email']; ?></td>
                                                <td><?= $student['phone']; ?></td>
                                                <td><?= $student['parent']; ?></td>
                                                <td class="widecolumn">
                                                    <a href="student-view.php?id=<?= $student['id']; ?>" class="btn btn-info btn-sm">View</a>
                                                    <a href="student-edit.php?id=<?= $student['id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                                    <form action="code.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete_student" value="<?=$student['id'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
                                ?>
                                
                            </tbody>
                        </table>
								
                    </div>
                </div>
            </div>
        </div>
    </div>

					   <!----edit-modal end--------->   
					   
					
	<!-- 2 </div> -->
		    <!------main-content-end-----------> 
		  
		 
		 
		 <!----footer-design------------->
		 
		 <footer class="footer ">
		    <div class="container-fluid">
			   <div class="footer-in">
			      <p class="mb-0"> Copyright © 2023 SPS. All Rights Reserved.</p>
			   </div>
			</div>
		 </footer>
		 
		 
		 
		 
	  </div>
   
</div>



<!-------complete html----------->





  
     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
  
  
  <script type="text/javascript">
       $(document).ready(function(){
	      $(".xp-menubar").on('click',function(){
		    $("#sidebar").toggleClass('active');
			$("#content").toggleClass('active');
		  });
		  
		  $('.xp-menubar,.body-overlay').on('click',function(){
		     $("#sidebar,.body-overlay").toggleClass('show-nav');
		  });
		  
	   });
  </script>

<script>
	 setTimeout(function() {
        const alertDiv = document.querySelector('.alert');
        if (alertDiv) {
            alertDiv.style.opacity = '0';
            setTimeout(function() {
                alertDiv.style.display = 'none';
            }, 500); 
        }
    }, 5000);
</script>
  
  



  </body>
  
  </html>


