<?php
    session_start();
    require 'dbcon2.php';
	
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
        <title>Student Performance System</title>
	    <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
	    <!----css3---->
        <link rel="stylesheet" href="css/custom.css">
		
		
		<!--google fonts -->
	    <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
	
	
	   <!--google material icon-->
      <link href="https://fonts.googleapis.com/css2?family=Material+Icons"rel="stylesheet">

  </head>
  <body>
 
<div class="wrapper">
     
	  <div class="body-overlay"></div>
	 
	 <!-------sidebar--design------------>
	 
	 <div id="sidebar">
	    <div class="sidebar-header pl-4 ml-2 pb-2">
		   <a href="index.php"><h3><img src="img/logo.png" class="img-fluid imgsize ml-4"/>Student Performance System</a></h3>
		</div>
		<ul class="list-unstyled component m-0">
		  <li class="">
		  <a href="index.php" class="dashboard"><i class="material-icons">dashboard</i>Dashboard </a>
		  </li>
		  <li class="dropdown">
		  <a href="infoguru.php" 
		  class="">
		  <i class="material-icons">info</i>Tentang Guru
		  </a>
		  </li>
		  <li class="dropdown">
		  <a href="chart.php">
		  <i class="material-icons">insert_chart</i>Chart
		  </a>
		  </li>
		  <li class="dropdown">
		  <a href="#homeSubmenu3" data-toggle="collapse" aria-expanded="false" 
		  class="dropdown-toggle">
		  <i class="material-icons">list</i>Laporan
		  </a>
		  <ul class="collapse list-unstyled menu" id="homeSubmenu3">
		  	 <li><a href="log.php">Data Monitoring</a></li>
		     <li class="active"><a href="nilai.php">Data Nilai Siswa</a></li>
		  </ul>
		  </li> 
		</ul>
	 </div>
	 
   <!-------sidebar--design- close----------->
   
   
   
      <!-------page-content start----------->
   
      <div id="content">
	     
		  <!------top-navbar-start-----------> 
		     
		  <div class="top-navbar">
		     <div class="xd-topbar">
			     <div class="row">
				     <div class="col-2 col-md-1 col-lg-1 order-2 order-md-1 align-self-center">
					    <div class="xp-menubar">
						    <span class="material-icons text-white">signal_cellular_alt</span>
						</div>
					 </div>
					 
					 <div class="col-md-5 col-lg-3 order-3 order-md-2">
					     <div class="xp-searchbar">
						     <form>
							 </form>
						 </div>
					 </div>
					 
					 
					 <div class="col-10 col-md-6 col-lg-8 order-1 order-md-3">
					     <div class="xp-profilebar text-right">
						    <nav class="navbar p-0">
							   <ul class="nav navbar-nav flex-row ml-auto">
							   <li class="dropdown nav-item active">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <span class="material-icons">notifications</span>
								  <span class="notification">3</span>
								 </a>
								  <ul class="dropdown-menu">
								  <li><a href="#"> Data Baru Telah Ditambahkan</a></li>
									 <li><a href="#"> Data Berhasil Diupdate</a></li>
									 <li><a href="#"> Data Berhasil Dihapus</a></li>
								  </ul>
							   </li>
							   <li class="dropdown nav-item">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <img src="img/profile.png" style="width:30px; border-radius:50%;"/>
								  <span class="xp-user-live"></span>
								 </a>
								  <ul class="dropdown-menu small-menu">
								     <li><a href="infoguru.php">
									 <span class="material-icons">person_outline</span>
									 Profile
									 </a></li>
									 <li><a href="#">
									 <span class="material-icons">settings</span>
									 Settings
									 </a></li>
									 <li><a href="login.php">
									 <span class="material-icons">logout</span>
									 Logout
									 </a></li>
									 <li><a href="register.php">
									 <span class="material-icons">how_to_reg</span>
									 Register
									 </a></li>
									 
								  </ul>
							   </li>
							   
							   
							   </ul>
							</nav>
						 </div>
					 </div>
					 
				 </div>
				 
				 <div class="xp-breadcrumbbar text-center">
				    <h4 class="page-title">Dashboard</h4>
					<ol class="breadcrumb">
					  <li class="breadcrumb-item">Laporan</li> <!--sebelum text bs input link-->
					  <li class="breadcrumb-item active" aria-curent="page">Data Nilai Siswa</li>
					</ol>
				 </div>
				 
				 
			 </div>
		  </div>
		  <!------top-navbar-end-----------> 
		  
		  
		   <!------main-content-start-----------> 
		     
		      <div class="container mt-4">

       
        <div class="row">
            <div class="col-md-12">
                <div class="card table-wrapper">
                    <div class="card-header table-title">
						<div class="row">
                            <div class="col-md-4 pt-3">
                            <h4>Data Nilai B. Inggris</h4> 
                            </div>
                            <div class="col-md-6 pr-5">
                            <?php include('message.php'); ?>
                            </div>
                            <div class="col-md-2 pt-3">
                            <a href="nilai-create.php" class="btn btn-primary float"> Add Data </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
					<form action="" method="GET">
    <label for="name">Search :</label>
    <input type="text" name="name" id="name">
    <button type="submit" name="search" class="btn btn-primary">Search</button>
</form>
                        <table class="table table-bordered table-secondary mt-3">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Student Name</th>
                                    <th>Quiz 1</th>
                                    <th>Quiz 2</th>
                                    <th>Quiz 3</th>
									<th>UTS</th>
									<th>UAS</th>
									<th>Quiz 1</th>
                                    <th>Quiz 2</th>
                                    <th>Quiz 3</th>
									<th>UTS</th>
									<th>UAS</th>
									<th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
				

                                <?php 
                                    $query = "SELECT * FROM student";
									// Check if the search form is submitted
								if (isset($_GET['search'])) {
									$name = $_GET['name'];
									
									// Add the name search filter to the query
									if (!empty($name)) {
										$query .= (strpos($query, 'WHERE') !== false) ? " AND name LIKE '%$name%'" : " WHERE name LIKE '%$name%'";
									}
								}
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $students)
                                        {
                                            ?>
                                            <tr>
                                                <td><?= $students['id']; ?></td>
                                                <td><?= $students['name']; ?></td>
												<td><?= $students['quiz1_1']; ?></td>
												<td><?= $students['quiz2_1']; ?></td>
												<td><?= $students['quiz3_1']; ?></td>
												<td><?= $students['uts_1']; ?></td>
												<td><?= $students['uas_1']; ?></td>
												<td><?= $students['quiz1_2']; ?></td>
												<td><?= $students['quiz2_2']; ?></td>
												<td><?= $students['quiz3_2']; ?></td>
												<td><?= $students['uts_2']; ?></td>
												<td><?= $students['uas_2']; ?></td>
                                                <td class="widecolumn">
                                                    <a href="nilai-view.php?id=<?= $students['id']; ?>" class="btn btn-info btn-sm">View</a>
                                                    <a href="nilai-edit.php?id=<?= $students['id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                                    <form action="code2.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete_nilai" value="<?=$students['id'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                    </form>
                                                   
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
                                ?>
                                
                            </tbody>
                        </table>
								
                    </div>
                </div>
            </div>
        </div>
    </div>

					   <!----edit-modal end--------->   
					   
					
	<!-- 2 </div> -->
		    <!------main-content-end-----------> 
		  
		 
		 
		 <!----footer-design------------->
		 
		 <footer class="footer ">
		    <div class="container-fluid">
			   <div class="footer-in">
			      <p class="mb-0"> Copyright © 2023 SPS. All Rights Reserved.</p>
			   </div>
			</div>
		 </footer>
		 
		 
		 
		 
	  </div>
   
</div>



<!-------complete html----------->





  
     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   <script src="js/jquery-3.3.1.slim.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/jquery-3.3.1.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  
  
  <script type="text/javascript">
       $(document).ready(function(){
	      $(".xp-menubar").on('click',function(){
		    $("#sidebar").toggleClass('active');
			$("#content").toggleClass('active');
		  });
		  
		  $('.xp-menubar,.body-overlay').on('click',function(){
		     $("#sidebar,.body-overlay").toggleClass('show-nav');
		  });
		  
	   });
  </script>

<script>
	 setTimeout(function() {
        const alertDiv = document.querySelector('.alert');
        if (alertDiv) {
            alertDiv.style.opacity = '0';
            setTimeout(function() {
                alertDiv.style.display = 'none';
            }, 500); 
        }
    }, 5000);
</script>
  
  



  </body>
  
  </html>


