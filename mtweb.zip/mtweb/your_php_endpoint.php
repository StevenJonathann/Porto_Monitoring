<?php
    session_start();
    require 'dbcon3.php';

	// Your database connection and query to fetch data
// Show data from database
$con = mysqli_connect("localhost","root","","php-crud3");
$query = "SELECT * FROM logs";
$result = mysqli_query($con, $query);

// Convert the result to JSON and output it
$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}
echo json_encode($data);
?>