<?php
$con = mysqli_connect("localhost", "root", "", "project");

if (!$con) {
    die('Connection Failed' . mysqli_connect_error());
}

// Fetch user data from the 'users' table
$query = "SELECT * FROM users";
$result = mysqli_query($con, $query);

// Store the user data in an array for displaying in the table
$users = array();
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>User Edit</title>
</head>
<body>
  
    <div class="container mt-5">
    
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-4">
                            <h4>User Edit</h4> 
                            </div>
                            <div class="col-md-2">
                            <?php include('message.php'); ?>
                            </div>
                            <div class="col-md-6">
                            <a href="setting.php" class="btn btn-danger float-end">BACK</a>    
                            </div>
                        </div>
                         
                         
                        
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $users_id = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM users WHERE id='$users_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $users = mysqli_fetch_array($query_run);
                                ?>
                                <form action="code4.php" method="POST" style="">
                                    <input type="hidden" name="users_id" value="<?= $users['id']; ?>">

                                    <div class="mb-3 col-md-3">
                                        <label>Name</label>
                                        <input type="text" name="username" value="<?=$users['username'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-3">
                                        <label>Email</label>
                                        <input type="email" name="email" value="<?=$users['email'];?>" class="form-control" autocomplete="off">
                                    </div>  
                                    <div class="mb-3">
                                        <button type="submit" name="update_users" class="btn btn-primary">
                                            Update
                                        </button>
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>