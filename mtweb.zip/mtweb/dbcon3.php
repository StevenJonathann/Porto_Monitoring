<?php

$con = mysqli_connect("localhost","root","","php-crud3");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>