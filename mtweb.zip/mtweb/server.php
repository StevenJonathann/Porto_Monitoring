<?php
session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'project');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
    array_push($errors, "The two passwords do not match");
  }

  // Check if the user already exists in the database
  $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) { // If user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "Email already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
    // No password hashing, directly store the plain text password
    $password = $password_1;

    // Default user_type will be "user"
    $user_type = "user";

    // Check if the username starts with "admin"
    // If it does, set the user_type to "admin"
    if (strpos($username, 'admin') === 0) {
      $user_type = "admin";
    }

    $query = "INSERT INTO users (username, email, password, user_type) 
              VALUES('$username', '$email', '$password', '$user_type')";

    // Execute the database insertion query
    if (mysqli_query($db, $query)) {
      $_SESSION['username'] = $username;
      $_SESSION['user_type'] = $user_type; // Store the user_type in the session as well
      $_SESSION['success'] = "You are now logged in";

      // Redirect users with the user_type "admin" to index.php
      // Redirect other users to index-siswa.php
      if ($user_type === 'admin') {
        header('location: index.php');
      } else {
        header('location: index-siswa.php');
      }
      exit(); // Make sure to add exit() to stop further execution of the script after redirection.
    } else {
      // If the database insertion fails, display an error message or handle it appropriately
      array_push($errors, "Failed to register user. Please try again later.");
    }
  }
}

// LOGIN USER
if (isset($_POST['login_user'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($username)) {
    array_push($errors, "Username is required");
  }
  if (empty($password)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['username'] = $username;

      // Fetch the user_type from the database and store it in the session
      $user = mysqli_fetch_assoc($results);

      // Check if the username starts with "admin"
      // If it does, set the user_type to "admin"
      if (strpos($username, 'admin') === 0) {
        $_SESSION['user_type'] = "admin";
      } else {
        $_SESSION['user_type'] = $user['user_type'];
      }

      // Redirect users with the user_type "admin" to index.php
      // Redirect other users to index-siswa.php
      if ($_SESSION['user_type'] === 'admin') {
        header('location: index.php');
      } else {
        header('location: index-siswa.php');
      }

      $_SESSION['success'] = "You are now logged in";
      exit(); // Make sure to add exit() to stop further execution of the script after redirection.
    } else {
      array_push($errors, "Wrong username/password combination");
    }
  }
}
?>
