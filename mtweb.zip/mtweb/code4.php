<?php
$con = mysqli_connect("localhost","root","","project");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}


if(isset($_POST['delete_users']))
{
    $users_id = mysqli_real_escape_string($con, $_POST['delete_users']);

    $query = "DELETE FROM users WHERE id='$users_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "User Deleted Successfully";
        header("Location: setting.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "User Not Deleted";
        header("Location: setting.php");
        exit(0);
    }
}

if (isset($_POST['update_users'])) {
    $users_id = mysqli_real_escape_string($con, $_POST['users_id']);
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $email = mysqli_real_escape_string($con, $_POST['email']);

    // Perform the UPDATE query to update the user's data in the database
    $query = "UPDATE users SET username='$username', email='$email' WHERE id='$users_id'";
    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        // The data has been updated successfully. You may display a success message or redirect back to the table page.
        // For example, you can use header() to redirect back to the page where the table is displayed.
        header("Location: setting.php"); // Replace 'index.php' with the actual page name where the table is displayed.
        exit;
    } else {
        // An error occurred during the update process. You may display an error message.
        echo "Error: " . mysqli_error($con);
    }
}


    if(isset($_POST['simpan_users']))
    {
        $username = mysqli_real_escape_string($con, $_POST['username']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
    
        $query = "INSERT INTO users (username,email) VALUES ('$username','$email')";

        $query_run = mysqli_query($con, $query);
        if($query_run)
        {
            $_SESSION['message'] = "User Created Successfully";
            header("Location: users-create.php");
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "User Not Created";
            header("Location: users-create.php");
            exit(0);
        }
    }
?>