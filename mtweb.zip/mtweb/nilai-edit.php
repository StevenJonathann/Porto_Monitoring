<?php
session_start();
require 'dbcon2.php';
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Student Edit</title>
</head>
<body>
  
    <div class="container mt-5">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Student Edit 
                            <a href="nilai.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $students_id = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM student WHERE id='$students_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $students = mysqli_fetch_array($query_run);
                                ?>
                                <form action="code2.php" method="POST">
                                    <input type="hidden" name="students_id" value="<?=$students['id']; ?>">

                                    <div class="mb-3 col-md-3">
                                        <label>Student Name</label>
                                        <input type="text" name="name" value="<?=$students['name'];?>" class="form-control">
                                    </div>
                                    <div class="row">
                                    <div class="mb-3 col-md-1">
                                        <label>Quiz 1</label>
                                        <input type="number" name="quiz1_1" value="<?=$students['quiz1_1'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-1">
                                        <label>Quiz 2</label>
                                        <input type="number" name="quiz2_1" value="<?=$students['quiz2_1'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-1">
                                        <label>Quiz 3</label>
                                        <input type="number" name="quiz3_1" value="<?=$students['quiz3_1'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-1">
                                        <label>UTS</label>
                                        <input type="number" name="uts_1" value="<?=$students['uts_1'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-1">
                                        <label>UAS</label>
                                        <input type="number" name="uas_1" value="<?=$students['uas_1'];?>" class="form-control">
                                    </div>
                                    <p class="mt-4 col-md-3">Semester 1</p>
                                    </div>
                                    <div class="row">
                                    <div class="mb-3 col-md-1">
                                        <label>Quiz 1</label>
                                        <input type="number" name="quiz1_2" value="<?=$students['quiz1_2'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-1">
                                        <label>Quiz 2</label>
                                        <input type="number" name="quiz2_2" value="<?=$students['quiz2_2'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-1">
                                        <label>Quiz 3</label>
                                        <input type="number" name="quiz3_2" value="<?=$students['quiz3_2'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-1">
                                        <label>UTS</label>
                                        <input type="number" name="uts_2" value="<?=$students['uts_2'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-1">
                                        <label>UAS</label>
                                        <input type="number" name="uas_2" value="<?=$students['uas_2'];?>" class="form-control">
                                    </div>
                                    <p class="mt-4 col-md-3">Semester 2</p>
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="update_nilai" class="btn btn-primary">
                                            Update
                                        </button>
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
	 setTimeout(function() {
        const alertDiv = document.querySelector('.alert');
        if (alertDiv) {
            alertDiv.style.opacity = '0';
            setTimeout(function() {
                alertDiv.style.display = 'none';
            }, 500); 
        }
    }, 5000);
</script>
</body>
</html>