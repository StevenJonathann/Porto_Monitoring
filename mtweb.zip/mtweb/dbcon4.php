<?php

$con = mysqli_connect("localhost","root","","project");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>