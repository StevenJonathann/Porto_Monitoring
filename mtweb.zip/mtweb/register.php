<?php include('server.php') ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/custom.css" />
    <title>Register</title>
  </head>
  <body>
  <div class="container text-white">
  <div class="row align-content-center mt-5 bg-secondary">
    <div class="col pb-3 text-center">
      <img
        src="img/logo.png"
        width="130"
        height="120"
        class="d-inline-block align-top"
        alt=""
      />
      <h4 class="pb-3 text-center">Register</h4>
      <form method="post" action="register.php" autocomplete="off">
        <?php include('errors.php'); ?>
        <div class="form-group">
          <label class="admin-cred" for="exampleInputUsername1">Username</label>
          <input
            type="text"
            class="form-control"
            id="exampleInputUsername1"
            aria-describedby="emailHelp"
            placeholder="Username"
            name="username"
          />
        </div>
        <div class="form-group">
          <label class="admin-cred" for="exampleInputEmail1">Email</label>
          <input
            type="text"
            class="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            placeholder="Email Address"
            name="email"
          />
        </div>
        <div class="form-group">
          <label class="admin-cred" for="exampleInputPassword1">Password</label>
          <input
            type="password"
            class="form-control"
            id="exampleInputPassword1"
            placeholder="Password"
            name="password_1"
          />
        </div>
        <div class="form-group">
          <label class="admin-cred" for="exampleInputPassword1">Confirm Password</label>
          <input
            type="password"
            class="form-control"
            id="exampleInputPassword1"
            placeholder="Confirm Password"
            name="password_2"
          />
        </div>
        <!-- You can add any other fields relevant to your registration form here -->

        <button type="submit" class="btn btn-primary admin-cred" name="reg_user">
          Register Now
        </button>
        <a href="#" class="btn btn-danger admin-cred">Cancel</a>
      </form>
    </div>
  </div>
</div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="retina/retina.min.js"></script>
    <script src="js/bootstrap.js"></script>
  </body>
</html>
