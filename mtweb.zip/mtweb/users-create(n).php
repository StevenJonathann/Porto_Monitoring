<?php
$con = mysqli_connect("localhost", "root", "", "project");

if (!$con) {
    die('Connection Failed' . mysqli_connect_error());
}

// Fetch user data from the 'users' table
$query = "SELECT * FROM users";
$result = mysqli_query($con, $query);

// Store the user data in an array for displaying in the table
$users = array();
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Users Create</title>
    <style>
        /* Custom styles for the bigger message on student-create.php */
        .custom-message {
            font-size: 20px !important; /* Adjust this value to set the desired font size */
            padding: 15px; /* Adjust this value to set the desired padding */
        }
        </style>
</head>
<body>
  
    <div class="container mt-5">

    <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Add User 
                            <a href="setting.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="server.php" method="POST">

                        <div class="mb-3 col-md-3">
                                <label>Name</label>
                                <input type="text" name="username" class="form-control">
                            </div>
                            <div class="mb-3 col-md-3">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" autocomplete="off">
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>