<?php
session_start();
require 'dbcon3.php';

// nilai
if(isset($_POST['delete_logs']))
{
    $logs_id = mysqli_real_escape_string($con, $_POST['delete_logs']);

    $query = "DELETE FROM logs WHERE id='$logs_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Log Deleted Successfully";
        header("Location: log.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Log Not Deleted";
        header("Location: log.php");
        exit(0);
    }
}

if(isset($_POST['update_logs']))
{
    $logs_id = mysqli_real_escape_string($con, $_POST['logs_id']);

    $name = mysqli_real_escape_string($con, $_POST['name']);
    $dates = mysqli_real_escape_string($con, $_POST['dates']);
    $kendala = mysqli_real_escape_string($con, $_POST['kendala']);
    $keterangan = mysqli_real_escape_string($con, $_POST['keterangan']);

    $query = "UPDATE logs SET name='$name', dates='$dates', kendala='$kendala', keterangan='$keterangan' WHERE id='$logs_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Log Updated Successfully";
        header("Location: log.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Log Not Updated";
        header("Location: log.php");
        exit(0);
    }

}


    if(isset($_POST['simpan_logs']))
    {
        $name = mysqli_real_escape_string($con, $_POST['name']);
        $dates = mysqli_real_escape_string($con, $_POST['dates']);
        $kendala = mysqli_real_escape_string($con, $_POST['kendala']);
        $keterangan = mysqli_real_escape_string($con, $_POST['keterangan']);
        
        $query = "INSERT INTO logs (name,dates,kendala,keterangan) VALUES ('$name','$dates','$kendala','$keterangan')";

        $query_run = mysqli_query($con, $query);
        if($query_run)
        {
            $_SESSION['message'] = "Log Created Successfully";
            header("Location: logs-create.php");
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "Log Not Created";
            header("Location: logs-create.php");
            exit(0);
        }
    }
?>