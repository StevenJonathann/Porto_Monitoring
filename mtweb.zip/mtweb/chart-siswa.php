<?php
    session_start();
    require 'dbcon.php';
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	  <title>Student Performance System</title>
	    <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
	    <!----css3---->
        <link rel="stylesheet" href="css/custom.css">
		
		
		
		<!--google fonts -->
	    <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
	
	
	   <!--google material icon-->
      <link href="https://fonts.googleapis.com/css2?family=Material+Icons"rel="stylesheet">

  </head>
  <body>
 
<div class="wrapper">
     
	  <div class="body-overlay"></div>
	 
	 <!-------sidebar--design------------>
	 
	 <div id="sidebar">
	    <div class="sidebar-header pl-4 ml-2 pb-2">
		   <a href="index-siswa.php"><h3><img src="img/logo.png" class="img-fluid imgsize ml-4"/>Student Performance System</a></h3>
		</div>
		<ul class="list-unstyled component m-0">
		  <li class="">
		  <a href="index-siswa.php" class="dashboard"><i class="material-icons">dashboard</i>Dashboard </a>
		  </li>
		  <li class="dropdown">
		  <a href="infoguru-siswa.php" 
		  class="">
		  <i class="material-icons">info</i>Tentang Guru
		  </a>
		  </li>
		  <li class="active">
		  <a href="chart-siswa.php">
		  <i class="material-icons">insert_chart</i>Chart
		  </a>
		  </li>
		  <li class="dropdown">
		  <a href="#homeSubmenu3" data-toggle="collapse" aria-expanded="false" 
		  class="dropdown-toggle">
		  <i class="material-icons">list</i>Laporan
		  </a>
		  <ul class="collapse list-unstyled menu" id="homeSubmenu3">
		  	 <li><a href="log-siswa.php">Data Monitoring</a></li>
		     <li><a href="nilai-siswa.php">Data Nilai Siswa</a></li>
		  </ul>
		  </li> 
		</ul>
	 </div>
	 
   <!-------sidebar--design- close----------->
   
   
   
      <!-------page-content start----------->
   
      <div id="content">
	     
		  <!------top-navbar-start-----------> 
		     
		  <div class="top-navbar">
		     <div class="xd-topbar">
			     <div class="row">
				     <div class="col-2 col-md-1 col-lg-1 order-2 order-md-1 align-self-center">
					    <div class="xp-menubar">
						    <span class="material-icons text-white">signal_cellular_alt</span>
						</div>
					 </div>
					 
					 <div class="col-md-5 col-lg-3 order-3 order-md-2">
					     <div class="xp-searchbar">
						     <form>
							 </form>
						 </div>
					 </div>
					 
					 
					 <div class="col-10 col-md-6 col-lg-8 order-1 order-md-3">
					     <div class="xp-profilebar text-right">
						    <nav class="navbar p-0">
							   <ul class="nav navbar-nav flex-row ml-auto">
							   <li class="dropdown nav-item active">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <span class="material-icons">notifications</span>
								  <span class="notification">3</span>
								 </a>
								  <ul class="dropdown-menu">
								  <li><a href="#"> Data Baru Telah Ditambahkan</a></li>
									 <li><a href="#"> Data Nilai Telah Terupdate</a></li>
									 <li><a href="#"> Data Telah Dihapus</a></li>
								  </ul>
							   </li>
							   <li class="dropdown nav-item">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <img src="img/profile.png" style="width:30px; border-radius:50%;"/>
								  <span class="xp-user-live"></span>
								 </a>
								  <ul class="dropdown-menu small-menu">
								  <li><a href="index-siswa.php">
									 <span class="material-icons">person_outline</span>
									 Profile
									 </a></li>
									 <li><a href="#">
									 <span class="material-icons">settings</span>
									 Manage User
									 </a></li>
									 <li><a href="login.php">
									 <span class="material-icons">logout</span>
									 Logout
									 </a></li>
									 <li><a href="register.php">
									 <span class="material-icons">how_to_reg</span>
									 Register
									 </a></li>
									 
								  </ul>
							   </li>
							   
							   
							   </ul>
							</nav>
						 </div>
					 </div>
					 
				 </div>
				 
				 <div class="xp-breadcrumbbar text-center">
				    <h4 class="page-title">Dashboard</h4>
					<ol class="breadcrumb">
					  <li class="breadcrumb-item">SPS</li> <!--sebelum text bs input link-->
					  <li class="breadcrumb-item active" aria-curent="page">Chart</li>
					</ol>
				 </div>
				 
				 
			 </div>
		  </div>
		  <!------top-navbar-end-----------> 
		  
		  
        <div class="container" style="margin-bottom:120px;">
            <div class="row" style="padding-top:80px;">
                <div class="col-md-6">
                <canvas id="lineChart1" ></canvas>
                </div>
                <div class="col-md-6">
                <canvas id="lineChart2" ></canvas>
                </div>
            </div>
        </div>
		 
		 
		 <!----footer-design------------->
		 
		 <footer class="footer ">
		    <div class="container-fluid">
			   <div class="footer-in">
			      <p class="mb-0"> Copyright © 2023 SPS. All Rights Reserved.</p>
			   </div>
			</div>
		 </footer>
		 
		 
		 
		 
	  </div>
   
</div>



<!-------complete html----------->





  
     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
  
  
  <script type="text/javascript">
       $(document).ready(function(){
	      $(".xp-menubar").on('click',function(){
		    $("#sidebar").toggleClass('active');
			$("#content").toggleClass('active');
		  });
		  
		  $('.xp-menubar,.body-overlay').on('click',function(){
		     $("#sidebar,.body-overlay").toggleClass('show-nav');
		  });
		  
	   });
  </script>

<script>
  // First line chart
  var ctxL1 = document.getElementById("lineChart1").getContext('2d');
  var myLineChart1 = new Chart(ctxL1, {
    type: 'line',
    data: {
      labels: ["January", "February", "March", "April", "May", "June", "July"],
      datasets: [{
        label: "Grafik Nilai Siswa",
        data: [70, 65, 69, 67, 70, 68, 72],
        backgroundColor: [
          'rgba(105, 0, 132, .2)',
        ],
        borderColor: [
          'rgba(200, 99, 132, .7)',
        ],
        borderWidth: 2
      }]
    },
    options: {
      responsive: true
    }
  });

  // Second line chart
  var ctxL2 = document.getElementById("lineChart2").getContext('2d');
  var myLineChart2 = new Chart(ctxL2, {
    type: 'line',
    data: {
      labels: ["January", "February", "March", "April", "May", "June", "July"],
      datasets: [{
        label: "Grafik Kendala",
        data: [54, 45, 48, 50, 43, 46, 44],
        backgroundColor: [
          'rgba(0, 137, 132, .2)',
        ],
        borderColor: [
          'rgba(0, 10, 130, .7)',
        ],
        borderWidth: 2
      }]
    },
    options: {
      responsive: true
    }
  });
</script>
  
  
  



  </body>
  
  </html>


