<?php

$con = mysqli_connect("localhost","root","","php-crud2");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>