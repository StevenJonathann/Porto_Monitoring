<?php
    session_start();
    require 'dbcon3.php';
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	  <title>Student Performance System</title>
	    <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
	    <!----css3---->
        <link rel="stylesheet" href="css/custom2.css">
		<link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">
		
		<!--google fonts -->
	    <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
	
	
	   <!--google material icon-->
      <link href="https://fonts.googleapis.com/css2?family=Material+Icons"rel="stylesheet">
	<style> #data-table .keterangan-column .tablelogsiswa {
    font-size: 14px; /* Adjust the font size as per your requirement */
}</style>
<style>
  /* Custom CSS to adjust table column widths */
  .tablelogsiswa th:nth-child(1),
  .tablelogsiswa td:nth-child(1) {
    width: 6%;
  }

  .tablelogsiswa th:nth-child(2),
  .tablelogsiswa td:nth-child(2),
  .tablelogsiswa th:nth-child(3),
  .tablelogsiswa td:nth-child(3),
  .tablelogsiswa th:nth-child(4),
  .tablelogsiswa td:nth-child(4) {
    width: 15%;
  }

  .tablelogsiswa th:nth-child(5),
  .tablelogsiswa td:nth-child(5) {
    width: 50%;
  }
</style>
  </head>
  <body>
 
<div class="wrapper">
     
	  <div class="body-overlay"></div>
	 
	 <!-------sidebar--design------------>
	 
	 <div id="sidebar">
	    <div class="sidebar-header pl-4 ml-2 pb-2">
		   <a href="index-siswa.php"><h3><img src="img/logo.png" class="img-fluid imgsize ml-4"/>Student Performance System</a></h3>
		</div>
		<ul class="list-unstyled component m-0">
		  <li class="">
		  <a href="index-siswa.php" class="dashboard"><i class="material-icons">dashboard</i>Dashboard </a>
		  </li>
		  <li class="dropdown">
		  <a href="infoguru-siswa.php" 
		  class="">
		  <i class="material-icons">info</i>Tentang Guru
		  </a>
		  </li>
		  <li class="">
		  <a href="chart-siswa.php">
		  <i class="material-icons">insert_chart</i>Chart
		  </a>
		  </li>
		  <li class="dropdown">
		  <a href="#homeSubmenu3" data-toggle="collapse" aria-expanded="false" 
		  class="dropdown-toggle">
		  <i class="material-icons">list</i>Laporan
		  </a>
		  <ul class="collapse list-unstyled menu" id="homeSubmenu3">
		  	 <li class="active"><a href="log-siswa.php">Data Monitoring</a></li>
		     <li><a href="nilai-siswa.php">Data Nilai Siswa</a></li>
		  </ul>
		  </li> 
		</ul>
	 </div>
	 
   <!-------sidebar--design- close----------->
   
   
   
      <!-------page-content start----------->
   
      <div id="content">
	     
		  <!------top-navbar-start-----------> 
		     
		  <div class="top-navbar">
		     <div class="xd-topbar">
			     <div class="row">
				     <div class="col-2 col-md-1 col-lg-1 order-2 order-md-1 align-self-center">
					    <div class="xp-menubar">
						    <span class="material-icons text-white">signal_cellular_alt</span>
						</div>
					 </div>
					 
					 <div class="col-md-5 col-lg-3 order-3 order-md-2">
					     <div class="xp-searchbar">
						     <form>
							 </form>
						 </div>
					 </div>
					 
					 
					 <div class="col-10 col-md-6 col-lg-8 order-1 order-md-3">
					     <div class="xp-profilebar text-right">
						    <nav class="navbar p-0">
							   <ul class="nav navbar-nav flex-row ml-auto">
							   <li class="dropdown nav-item active">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <span class="material-icons">notifications</span>
								  <span class="notification">3</span>
								 </a>
								  <ul class="dropdown-menu">
								  <li><a href="#"> Data Baru Telah Ditambahkan</a></li>
									 <li><a href="#"> Data Nilai Telah Terupdate</a></li>
									 <li><a href="#"> Data Telah Dihapus</a></li>
								  </ul>
							   </li>
							   <li class="dropdown nav-item">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <img src="img/profile.png" style="width:30px; border-radius:50%;"/>
								  <span class="xp-user-live"></span>
								 </a>
								  <ul class="dropdown-menu small-menu">
								  <li><a href="index-siswa.php">
									 <span class="material-icons">person_outline</span>
									 Profile
									 </a></li>
									 <li><a href="#">
									 <span class="material-icons">settings</span>
									 Manage User
									 </a></li>
									 <li><a href="login.php">
									 <span class="material-icons">logout</span>
									 Logout
									 </a></li>
									 <li><a href="register.php">
									 <span class="material-icons">how_to_reg</span>
									 Register
									 </a></li>
									 
								  </ul>
							   </li>
							   
							   
							   </ul>
							</nav>
						 </div>
					 </div>
					 
				 </div>
				 
				 <div class="xp-breadcrumbbar text-center">
				    <h4 class="page-title">Dashboard</h4>
					<ol class="breadcrumb">
					  <li class="breadcrumb-item">Laporan</li> <!--sebelum text bs input link-->
					  <li class="breadcrumb-item active" aria-curent="page">Data Monitoring</li>
					</ol>
				 </div>
				 
				 
			 </div>
		  </div>
		  <!------top-navbar-end-----------> 
		  
		   <!------main-content-start-----------> 
		     
		      <div class="container mt-4">

			 
        <div class="row">
            <div class="col-md-12">
                <div class="card table-wrapper">
                    <div class="card-header table-title">
                        <div class="row">
                            <div class="col-md-4 pt-3">
                            <h4>Data Monitoring</h4> 
                            </div>
                            <div class="col-md-6 pr-5">
                            <?php include('message.php'); ?>
                            </div>
                            <div class="col-md-2 pt-3">
                            
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
					<form action="" method="GET" class="mb-2">
    <label for="date">Filter :</label>
    <input type="date" name="date" id="date">
    <button type="submit" name="filter" class="btn btn-primary">Filter</button>
	<button id="printToPDFButton" class="btn btn-primary float" onclick="convertToPDF()">Print to PDF</button>
</form>

<!-- Form for searching by name -->
<form action="" method="GET">
    <label for="name">Search :</label>
    <input type="text" name="name" id="name">
    <button type="submit" name="search" class="btn btn-primary">Search</button>
</form>

                        <table id="data-table" class="table table-bordered table-primary table-hover mt-3 tablelogsiswa">
                            <thead>
                                <tr>
                                    <th class="col-md-1">ID</th>
                                    <th class="col-md-2">Student Name</th>
                                    <th class="col-md-2">Date</th>
                                    <th class="col-md-2">Jenis Kendala</th>
                                    <th class="col-md-4">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
				

                                <?php 
								
                                    $query = "SELECT * FROM logs";
									if (isset($_GET['filter'])) {
										$date = $_GET['date'];
										
										// Add the date filter to the query
										if (!empty($date)) {
											$query .= " WHERE dates = '$date'";
										}
									}
									
									// Check if the search form is submitted
									if (isset($_GET['search'])) {
										$name = $_GET['name'];
										
										// Add the name search filter to the query
										if (!empty($name)) {
											$query .= (strpos($query, 'WHERE') !== false) ? " AND name LIKE '%$name%'" : " WHERE name LIKE '%$name%'";
										}
									}
									
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $logs)
                                        {
                                            ?>
                                            <tr>
                                                <td><?= $logs['id']; ?></td>
                                                <td><?= $logs['name']; ?></td>
                                                <td><?= $logs['dates']; ?></td>
                                                <td><?= $logs['kendala']; ?></td>
                                                <td class="keterangan-column"><?= $logs['keterangan']; ?></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
                                ?>
                                
                            </tbody>
                        </table>
								
                    </div>
                </div>
            </div>
        </div>
    </div>

					   <!----edit-modal end--------->   
					   
					
	<!-- 2 </div> -->
		    <!------main-content-end-----------> 
		  
		 
		 
		 <!----footer-design------------->
		 
		 <footer class="footer ">
		    <div class="container-fluid">
			   <div class="footer-in">
			      <p class="mb-0"> Copyright © 2023 SPS. All Rights Reserved.</p>
			   </div>
			</div>
		 </footer>
		 
		 
		 
		 
	  </div>
   
</div>



<!-------complete html----------->





  
     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   <script src="js/jquery-3.3.1.slim.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/jquery-3.3.1.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.0/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.15/jspdf.plugin.autotable.min.js"></script>

<script type="text/javascript">
       $(document).ready(function(){
	      $(".xp-menubar").on('click',function(){
		    $("#sidebar").toggleClass('active');
			$("#content").toggleClass('active');
		  });
		  
		  $('.xp-menubar,.body-overlay').on('click',function(){
		     $("#sidebar,.body-overlay").toggleClass('show-nav');
		  });
		  
	   });
  </script>
  
  <script>
	 setTimeout(function() {
        const alertDiv = document.querySelector('.alert');
        if (alertDiv) {
            alertDiv.style.opacity = '0';
            setTimeout(function() {
                alertDiv.style.display = 'none';
            }, 500); 
        }
    }, 5000);
</script>

<script>
  function convertToPDF() {
    const doc = new window.jspdf.jsPDF();
    const table = document.getElementById("data-table");

    // Convert the table to a data array
    const data = [];
    const headers = [];
    const rows = table.querySelectorAll("tr");
    for (const row of rows) {
      const rowData = [];
      const cells = row.querySelectorAll("th, td");
      cells.forEach((cell) => {
        rowData.push(cell.textContent);
      });
      if (row.tagName === "TH") {
        headers.push(rowData);
      } else {
        data.push(rowData);
      }
    }

    // Create the PDF with the table
    doc.autoTable({
      head: headers,
      body: data,
    });

    // Save the PDF
    doc.save("table_data.pdf");
  }
</script>



  </body>
  
  </html>


