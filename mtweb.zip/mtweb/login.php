<?php include('server.php')?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/custom.css" />
    <link rel="stylesheet" href="css/style.css" />
    <title>Login</title>
  </head>
  <body>

  <div class="container containerr text-black card">
  <div class="row align-content-center mt-5 ">
    <div class="col pb-3 text-center">
      <?php include('errors.php'); ?>
      <img
        src="img/logo.png"
        width="130"
        height="120"
        class="d-inline-block align-top"
        alt=""
      />
      <h4 class="pb-3 text-center">Login</h4>
      <form method="post" action="login.php" autocomplete="off">
        <div class="form-group">
          <label class="admin-cred" for="exampleInputEmail1">Username</label>
          <input
            type="text"
            class="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            placeholder="Username"
            name="username"
          />
        </div>
        <div class="form-group">
          <label class="admin-cred" for="exampleInputPassword1">Password</label>
          <input
            type="password"
            class="form-control"
            id="exampleInputPassword1"
            placeholder="Password"
            name="password"
          />
        </div>
        <div class="form-check pb-3">
          <input
            type="checkbox"
            class="form-check-input mt-2"
            id="exampleCheck1"
            name="remember_me"
          />
          <label class="form-check-label pb-1" for="exampleCheck1">Remember Me</label>
        </div>
        <!-- You can add any other fields relevant to your login form here -->

        <button type="submit" class="btn btn-primary admin-cred" name="login_user">
          Login Now
        </button>

        <p>
          Create an account? <a href="register.php">Sign up</a>
        </p>
      </form>
    </div>
  </div>
</div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="retina/retina.min.js"></script>
    <script src="js/bootstrap.js"></script>
  </body>
</html>
